<html>

<head>
    <title>latihan2</title>
</head>

<body>
    Halo kawan.. Yuk kita belajar web programming..!!!<br>
    Nilai 1 = <?= $nilai1; ?>
    Nilai 2 = <?= $nilai2; ?>
    ini hasil dari permodelan dengan metode penjumlahan yaitu <?=
$nilai1 . " + " . $nilai2 . " + " . $hasil; ?>

</body>

</html>