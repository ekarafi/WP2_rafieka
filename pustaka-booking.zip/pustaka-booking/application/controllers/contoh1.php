<?php
class Contoh1 extends CI_Controller
{
    public function index ()
    {
        echo "<h1>Perkenalkan</h1>";
        echo "Nama saya Rafi Eka 
            Saya tinggal di daerah Cileungsi
            hobby yang saya suka adalah mendengarkan Musik";
    }
}