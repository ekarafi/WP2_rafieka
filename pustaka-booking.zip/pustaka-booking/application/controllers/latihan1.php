<?php
class latihan1 extends CI_Controller
{
    public function index ()
    {
        echo "<h1>Biodata Mahasiswa BSI</h1>";
        echo "Nama : Rafi Eka Candra<br>";
        echo "Nim : 19220615<br>";
        echo "Kelas : 19.3A.24<br>";
        echo "Umur : 19 Tahun<br>";
        echo "Alamat : Cileungsi, Bogor<br>";
        echo "No.Hp : 081386692760<br>";
        echo "Hobby : Mendengarkan Musik<br>";
    }
}
?>